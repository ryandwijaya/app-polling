$("#font-jam").change(function () {
	var gayaTulisan = $(this).val();
	$('#preview-jam').css("font-family", gayaTulisan);
});

$("#color-jam").change(function () {
	var colorTulisan = $(this).val();
	$('#preview-jam').css("color", colorTulisan);
});

$("#size-jam").change(function () {
	var sizeTulisan = $(this).val();
	$('#preview-jam').css("font-size", sizeTulisan+'pt');
});


//judul
$("#font-judul").change(function () {
	var gayaTulisan = $(this).val();
	$('#preview-judul').css("font-family", gayaTulisan);
});

$("#color-judul").change(function () {
	var colorTulisan = $(this).val();
	$('#preview-judul').css("color", colorTulisan);
});

$("#size-judul").change(function () {
	var sizeTulisan = $(this).val();
	$('#preview-judul').css("font-size", sizeTulisan+'pt');
});


//alamat
$("#font-alamat").change(function () {
	var gayaTulisan = $(this).val();
	$('#preview-alamat').css("font-family", gayaTulisan);
});

$("#color-alamat").change(function () {
	var colorTulisan = $(this).val();
	$('#preview-alamat').css("color", colorTulisan);
});

$("#size-alamat").change(function () {
	var sizeTulisan = $(this).val();
	$('#preview-alamat').css("font-size", sizeTulisan+'pt');
});




//ptn
$("#font-ptn").change(function () {
	var gayaTulisan = $(this).val();
	$('#preview-ptn').css("font-family", gayaTulisan);
});

$("#color-ptn").change(function () {
	var colorTulisan = $(this).val();
	$('#preview-ptn').css("color", colorTulisan);
});

$("#size-ptn").change(function () {
	var sizeTulisan = $(this).val();
	$('#preview-ptn').css("font-size", sizeTulisan+'pt');
});




//text
$("#font-text").change(function () {
	var gayaTulisan = $(this).val();
	$('#preview-text').css("font-family", gayaTulisan);
});

$("#color-text").change(function () {
	var colorTulisan = $(this).val();
	$('#preview-text').css("color", colorTulisan);
});

$("#size-text").change(function () {
	var sizeTulisan = $(this).val();
	$('#preview-text').css("font-size", sizeTulisan+'pt');
});

