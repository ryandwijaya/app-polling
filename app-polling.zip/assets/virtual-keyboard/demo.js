$(document).ready(function(){
  $('input.example-1').mlKeyboard({layout: 'en_US',width: '1200px'});
});
$(document).ready(function(){
  $('input.example-2').mlKeyboard({layout: 'en_US'});
});
$(document).ready(function(){
  $('input.example-3').mlKeyboard({layout: 'en_US'});
});

$(document).ready(function(){
  $('input.example-4').mlKeyboard({layout: 'en_US'});
});

$(document).ready(function(){
  $('input.example-5').mlKeyboard({layout: 'en_US'});
});
$(document).ready(function(){
  $('textarea.example-1').mlKeyboard({layout: 'en_US'});
});


