###################
APLIKASI IKM KEPUASAN MASYARAKAT
###################

*******************
Framework
*******************

To download the latest stable release please visit the `CodeIgniter Downloads
<https://codeigniter.com/download>`_ page.


*******************
Server Requirements
*******************

PHP version 7 or newer is recommended.
